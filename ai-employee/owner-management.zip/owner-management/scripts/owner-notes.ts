import axios from 'axios';

const BASE = process.env.CRM_API_BASE;
const TOKEN = process.env.CRM_TOKEN;
const headers = { Authorization: `Bearer ${TOKEN}`, 'Content-Type': 'application/json' };

async function main() {
  const raw = process.argv[2];
  if (!raw) {
    console.error('Usage: owner-notes.ts \'<json with action and ownerId>\'');
    process.exit(1);
  }

  const { action, ownerId, noteId, content } = JSON.parse(raw);
  if (!ownerId) { console.error('Error: ownerId is required.'); process.exit(1); }

  if (action === 'list') {
    const res = await axios.get(`${BASE}/api/crm/owners/${ownerId}/notes`, { headers });
    const notes = res.data;
    if (!notes.length) { console.log('No notes found.'); return; }
    notes.forEach((n: any) => console.log(`- [${n.noteId}] ${n.content} (${n.createdAt?.slice(0,10)})`));

  } else if (action === 'add') {
    if (!content) { console.error('Error: content is required for add.'); process.exit(1); }
    const res = await axios.post(`${BASE}/api/crm/owners/${ownerId}/notes`, { content }, { headers });
    console.log(`Note added: [${res.data.noteId}] ${res.data.content}`);

  } else if (action === 'update') {
    if (!noteId || !content) { console.error('Error: noteId and content required for update.'); process.exit(1); }
    await axios.put(`${BASE}/api/crm/owners/${ownerId}/notes/${noteId}`, { content }, { headers });
    console.log(`Note [${noteId}] updated.`);

  } else if (action === 'delete') {
    if (!noteId) { console.error('Error: noteId required for delete.'); process.exit(1); }
    await axios.delete(`${BASE}/api/crm/owners/${ownerId}/notes/${noteId}`, { headers });
    console.log(`Note [${noteId}] deleted.`);

  } else {
    console.error('Unknown action. Use: list | add | update | delete');
    process.exit(1);
  }
}

main().catch(e => {
  console.error('Error:', e.response?.data?.error || e.message);
  process.exit(1);
});
